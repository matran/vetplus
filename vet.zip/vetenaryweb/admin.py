from django.contrib import admin
from .models import Disease
admin.site.register(Disease)