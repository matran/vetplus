from django.contrib import admin
from .models import Disease
from .models import Symptoms
admin.site.register(Disease)
admin.site.register(Symptoms)